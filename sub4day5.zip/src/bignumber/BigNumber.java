package bignumber;

public interface BigNumber {

  int length();

  double shiftLeft(int lShift);

  double shiftRight(int rShift);
//
//  BigNumber addDigit(double num) throws IllegalArgumentException;
//
//  double getDigitAt(double pos) throws IllegalArgumentException;
//
//  double copy();
//
//  double add(BigNumber bigNum);
//
//  boolean cmp(BigNumber bNum1, BigNumber bNum2);

}
