package bignumber;

public class BigNumberImpl implements BigNumber {

  private String data;

  public BigNumberImpl(String data) {
    this.data = data;
  }

  @Override
  public int length() {
    return data.length();
  }

  @Override
  public double shiftRight(int rShift) {
    if (rShift > 0) {
      int temp = Integer.parseInt(this.data);
      return temp / Math.pow(10, rShift);
    } else
      return shiftLeft(Math.abs(rShift));
  }

  @Override
  public double shiftLeft(int lShift) {
    if (lShift > 0) {
      int temp = Integer.parseInt(this.data);
      return temp * Math.pow(10, lShift);
    } else {
      return shiftRight(Math.abs(lShift));
    }
  }
}