package bignumber;

public class BigNumberImpl implements BigNumber {

  private Numbers data;
  private BigNumber rest;

  public BigNumberImpl(Numbers data, BigNumber rest) {
    this.data = data;
    this.rest = rest;
  }

  public int length() {
    return 1 + this.rest.length();
  }
}