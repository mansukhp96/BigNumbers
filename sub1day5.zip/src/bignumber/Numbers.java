package bignumber;

public class Numbers {
  private int num;

  public Numbers(int num) {
    this.num = num;
  }

  public int getNum() {
    return this.num;
  }
}