import org.junit.Test;

import bignumber.BigNumber;
import bignumber.BigNumberImpl;
import bignumber.EmptyBigNumber;
import bignumber.Numbers;

import static org.junit.Assert.assertEquals;

public class BigNumberImplTest {

  private BigNumber num;

  @Test
  public void testInit() {
    num = new BigNumberImpl(new Numbers(1),
            new BigNumberImpl(new Numbers(2),
                    new BigNumberImpl(new Numbers(3),
                            new EmptyBigNumber())));
    assertEquals("yo", num.length());
  }
}
