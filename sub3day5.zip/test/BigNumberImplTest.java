import org.junit.Test;

import bignumber.BigNumber;
import bignumber.BigNumberImpl;
import bignumber.EmptyBigNumber;
import bignumber.Numbers;

import static org.junit.Assert.assertEquals;

public class BigNumberImplTest {

  private BigNumber num;

  @Test
  public void testInit() {
    num = new BigNumberImpl(new Numbers("19"));
    assertEquals("yo", num.length());
  }
}
