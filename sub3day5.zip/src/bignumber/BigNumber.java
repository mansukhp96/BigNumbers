package bignumber;

public interface BigNumber {

  int length();

//  BigNumber shiftLeft(double shift);
//
//  BigNumber shiftRight(double shift);
//
//  BigNumber addDigit(double num) throws IllegalArgumentException;
//
//  double getDigitAt(double pos) throws IllegalArgumentException;
//
//  double copy();
//
//  double add(BigNumber bigNum);
//
//  boolean cmp(BigNumber bNum1, BigNumber bNum2);

}
