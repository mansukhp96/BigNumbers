package bignumber;

public class EmptyBigNumber implements BigNumber {

  public EmptyBigNumber() {
  }

  public int length() {
    return 0;
  }
}