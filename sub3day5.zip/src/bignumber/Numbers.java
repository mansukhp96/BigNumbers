package bignumber;

public class Numbers {
  private String numStr;

  public Numbers(String numStr) {
    this.numStr = numStr;
  }

  public int length(){
    return String.valueOf(this.numStr).length();
  }
}