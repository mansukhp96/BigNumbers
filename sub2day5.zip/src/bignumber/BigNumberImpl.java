package bignumber;

public class BigNumberImpl implements BigNumber {

  private Numbers data;
  private BigNumber rest;

  public BigNumberImpl(Numbers data) {
    this.data = data;
    this.rest = rest;
  }

  public int length() {
    return data.length();
  }
}